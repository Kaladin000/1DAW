public class Guías {

	private string Nombre;
	private string Dirección;
	private string Teléfono;
	private string fechaComienzo;
	private string horaTrabajo;

	public string getHoraTrabajo() {
		return this.horaTrabajo;
	}

	/**
	 * 
	 * @param parameter
	 */
	public void setHoraTrabajo(string parameter) {
		this.horaTrabajo = parameter;
	}

}