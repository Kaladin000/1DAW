public class Zonas {

	private double Extensión;
	private string Nombre;

	public double getExtensión() {
		// TODO - implement Zonas.getExtensión
		throw new UnsupportedOperationException();
	}

}