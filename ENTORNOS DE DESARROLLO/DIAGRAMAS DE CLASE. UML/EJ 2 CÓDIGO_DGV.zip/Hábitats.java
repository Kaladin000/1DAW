public class Hábitats {

	private string Clima;
	private string Nombre;
	private string Vegetación;
	private string[] Continentes;

	public string getClima() {
		// TODO - implement Hábitats.getClima
		throw new UnsupportedOperationException();
	}

	public string getVegetación() {
		// TODO - implement Hábitats.getVegetación
		throw new UnsupportedOperationException();
	}

	public string getNombre() {
		// TODO - implement Hábitats.getNombre
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param parameter
	 */
	public void setNombre(string parameter) {
		// TODO - implement Hábitats.setNombre
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param parameter
	 */
	public void setContinentes(string[] parameter) {
		// TODO - implement Hábitats.setContinentes
		throw new UnsupportedOperationException();
	}

}