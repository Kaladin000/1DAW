public class Itinerarios {

	private int Código;
	private double Longitud;
	private int Duración;
	private int visitantesMáximos;
	private int NEspecies;

	public int getCódigo() {
		// TODO - implement Itinerarios.getCódigo
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param parameter
	 */
	public void setCódigo(int parameter) {
		// TODO - implement Itinerarios.setCódigo
		throw new UnsupportedOperationException();
	}

}