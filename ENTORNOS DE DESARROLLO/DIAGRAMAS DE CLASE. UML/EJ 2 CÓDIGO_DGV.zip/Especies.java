public class Especies {

	private string nombreEspañol;
	private string NombreCientífico;
	private string Descripción;

	public string getNombreEspañol() {
		return this.nombreEspañol;
	}

	public string getNombreCientífico() {
		// TODO - implement Especies.getNombreCientífico
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param parameter
	 */
	public void setNombreEspañol(string parameter) {
		this.nombreEspañol = parameter;
	}

	/**
	 * 
	 * @param parameter
	 */
	public void setNombreCientífico(string parameter) {
		// TODO - implement Especies.setNombreCientífico
		throw new UnsupportedOperationException();
	}

}