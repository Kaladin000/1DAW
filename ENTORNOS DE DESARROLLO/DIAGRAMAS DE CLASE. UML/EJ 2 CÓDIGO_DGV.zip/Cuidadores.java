public class Cuidadores {

	private string Dirección;
	private string Nombre;
	private string Teléfono;
	private string fechaComienzo;
	private string fechaCuidado;

	public string getFechaCuidado() {
		return this.fechaCuidado;
	}

	/**
	 * 
	 * @param parameter
	 */
	public void setFechaCuidado(string parameter) {
		this.fechaCuidado = parameter;
	}

}